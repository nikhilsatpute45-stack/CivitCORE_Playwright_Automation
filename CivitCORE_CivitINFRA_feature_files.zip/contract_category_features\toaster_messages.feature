@ContractorCategory @ToasterMessages
Feature: Toaster Messages
  Automated scenarios for the "Toaster Messages" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: FRD Sec 7 (toasters only for listed events); FRD 5.2 FB-4
  @TC_CC_190 @Negative @High @Automation
  Scenario: Verify no toaster is shown for validation failures
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | (blank) |
      | Description | (blank) |
    When the user clicks Save with both fields empty
    And the user observes the screen for 5 seconds
    Then Only field-level error messages are shown; no toaster appears

  # Ref: FRD Sec 7 (toasters only for listed events); FRD 5.5 FB-5
  @TC_CC_191 @Negative @Medium @Automation
  Scenario: Verify no toaster is shown for Edit with no change
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-I |
    When the user does not change any field
    And the user clicks Save
    And the user observes the screen
    Then No toaster is displayed (toasters appear only for events listed in the FRD)
