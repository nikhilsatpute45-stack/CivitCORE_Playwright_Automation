@ContractorCategory @ContractorCategoryInitiation
Feature: Contractor Category Initiation
  Automated scenarios for the "Contractor Category Initiation" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: FRD 5.1 FB-1; FRD 5.1 FB-2; US-1 AC-1; US-1 AC-4
  @TC_CC_001 @Functional @High @Automation
  Scenario: Verify the Contractor Category List is displayed on navigating to Admin > Configuration > Contractor Category
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the CivitINFRA home page
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Admin_User1                                 |
      | Path | Admin > Configuration > Contractor Category |
    When the user expands Admin in the left navigation tree
    And the user expands Configuration
    And the user clicks 'Contractor Category'
    And the user observes the page that loads
    Then Contractor Category List is displayed as the landing view with columns Sl. No., Code, Description, Specialization and Actions
    And 'Add' button is displayed above the grid

  # Ref: US-1 AC-2; FRD Overview
  @TC_CC_002 @Functional @Medium @Automation
  Scenario: Verify default Contractor Categories are listed like any other Contractor Category
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Default records | Class-I, Class-II, Class-III, Class-IV (not deleted) |
    When the user observes the rows of the grid
    Then Class-I, Class-II, Class-III and Class-IV are listed with Sl. No. 1 to 4, in the same way as any other Contractor Category

  # Ref: FRD 5.1 FB-4; US-1 AC-5
  @TC_CC_003 @Functional @High @Automation
  Scenario: Verify the kebab menu shows View, Edit and Delete to a user holding all permissions
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Admin_User1 |
      | Row  | Class-I     |
    When the user clicks the kebab (⋮) icon in the Actions column of row 'Class-I'
    And the user observes the menu options
    Then Menu shows View, Edit and Delete

  # Ref: FRD 5.3 BR-1; FRD 5.1 BR-2; US-1 AC-4; US-1 AC-5
  @TC_CC_004 @Functional @High @Automation
  Scenario: Verify a view-only user sees the list, no 'Add' button and only 'View' in the kebab menu
    Given Viewer_User1 (Contractor Category: View only) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Viewer_User1 |
      | Row  | Class-I      |
    When the user observes the area above the grid
    And the user clicks the kebab (⋮) icon of row 'Class-I'
    And the user observes the menu options
    Then Contractor Category List is visible (List is available to any user holding View permission)
    And 'Add' button is not displayed
    And Only 'View' is shown in the kebab menu; Edit and Delete are not shown

  # Ref: FRD 5.1 BR-1; FRD 5.1 BR-2; US-1 AC-4; US-1 AC-5
  @TC_CC_005 @Functional @High @Automation
  Scenario: Verify a user with Add permission sees the 'Add' button and only 'View' in the kebab menu
    Given Adder_User1 (Contractor Category: View + Add) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Adder_User1 |
      | Row  | Class-I     |
    When the user observes the area above the grid
    And the user clicks the kebab (⋮) icon of row 'Class-I'
    Then 'Add' button is displayed
    And Kebab menu shows only 'View'

  # Ref: FRD 5.1 BR-2; US-1 AC-5
  @TC_CC_006 @Functional @High @Automation
  Scenario: Verify a user with Edit permission sees View and Edit (not Delete) and no 'Add' button
    Given Editor_User1 (Contractor Category: View + Edit) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Editor_User1 |
      | Row  | Class-I      |
    When the user observes the area above the grid
    And the user clicks the kebab (⋮) icon of row 'Class-I'
    Then 'Add' button is not displayed
    And Kebab menu shows 'View' and 'Edit'; 'Delete' is not shown

  # Ref: FRD 5.1 BR-2; US-1 AC-5
  @TC_CC_007 @Functional @High @Automation
  Scenario: Verify a user with Delete permission sees View and Delete (not Edit) in the kebab menu
    Given Deleter_User1 (Contractor Category: View + Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Deleter_User1 |
      | Row  | Class-I       |
    When the user clicks the kebab (⋮) icon of row 'Class-I'
    And the user observes the menu options
    Then Kebab menu shows 'View' and 'Delete'; 'Edit' is not shown

  # Ref: FRD 5.1 FB-5
  @TC_CC_008 @Functional @Medium @Automation
  Scenario: Verify clicking outside an open kebab menu closes it without performing any action
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-I |
    When the user clicks the kebab (⋮) icon of row 'Class-I'
    And the user clicks on an empty area of the page outside the menu
    Then Kebab menu closes; no pop-up opens and no data changes

  # Ref: FRD 5.1 FB-5
  @TC_CC_009 @Functional @Medium @Automation
  Scenario: Verify pressing Esc closes an open kebab menu without performing any action
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-I |
    When the user clicks the kebab (⋮) icon of row 'Class-I'
    And the user presses the Esc key
    Then Kebab menu closes; no pop-up opens and no data changes

  # Ref: FRD 5.1 FB-5
  @TC_CC_010 @Functional @Medium @Automation
  Scenario: Verify only one kebab menu can be open at a time
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Rows | Class-I, Class-II |
    When the user clicks the kebab (⋮) icon of row 'Class-I'
    And the user clicks the kebab (⋮) icon of row 'Class-II'
    And the user observes the open menus
    Then The menu of 'Class-I' closes and only the menu of 'Class-II' is open

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: FRD 5.1 BR-4
  @TC_CC_120 @Negative @High @Automation
  Scenario: Verify a user without View permission does not see the Contractor Category entry in the navigation tree
    Given NoAccess_User1 (no Contractor Category permission) is logged in
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | NoAccess_User1 |
    When the user expands Admin > Configuration in the left navigation tree
    Then 'Contractor Category' entry is not displayed in the navigation tree

  # Ref: FRD 5.1 BR-4; FRD 5.1 BR-3
  @TC_CC_121 @Negative @High @Automation
  Scenario: Verify a user without View permission is denied when opening the screen URL directly
    Given NoAccess_User1 (no Contractor Category permission) is logged in
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | NoAccess_User1 |
    When the user opens the Contractor Category screen URL directly in the browser
    Then Access is denied; no Contractor Category data is exposed

  # Ref: FRD 5.1 BR-3; FRD 5.1 BR-1
  @TC_CC_122 @Negative @High @Automation
  Scenario: Verify a view-only user cannot create a Contractor Category via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User    | Viewer_User1                                  |
      | Payload | {code:'Class-V', description:'Class-V Roads'} |
    When the user sends a create Contractor Category request
    And the user checks the master
    Then Request is rejected (403); no record is created and no toaster is displayed

  # Ref: FRD 5.1 BR-3; FRD 5.1 BR-1
  @TC_CC_123 @Negative @High @Automation
  Scenario: Verify a view-only user cannot update a Contractor Category via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User    | Viewer_User1                           |
      | Payload | {code:'Class-I', description:'Hacked'} |
    When the user sends an update request for Class-I
    And the user checks the record
    Then Request is rejected (403); record is unchanged; no toaster is displayed

  # Ref: FRD 5.1 BR-3; FRD 5.1 BR-1
  @TC_CC_124 @Negative @High @Automation
  Scenario: Verify a view-only user cannot delete a Contractor Category via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Viewer_User1 |
      | Row  | Class-IV     |
    When the user sends a delete request for unused Class-IV
    And the user checks the master
    Then Request is rejected (403); 'Class-IV' still exists; no toaster is displayed

  # Ref: FRD 5.1 BR-3; FRD 5.1 BR-2
  @TC_CC_125 @Negative @High @Automation
  Scenario: Verify an Add-only user cannot edit or delete via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Adder_User1 |
    When the user sends an update request for Class-I
    And the user sends a delete request for Class-IV
    Then Both requests are rejected (403); records unchanged

  # Ref: FRD 5.1 BR-3; FRD 5.1 BR-2
  @TC_CC_126 @Negative @High @Automation
  Scenario: Verify an Edit-only user cannot create or delete via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User    | Editor_User1                            |
      | Payload | {code:'Class-V', description:'Class-V'} |
    When the user sends a create request
    And the user sends a delete request for Class-IV
    Then Both requests are rejected (403); no record created or deleted

  # Ref: FRD 5.1 BR-3; FRD 5.1 BR-2
  @TC_CC_127 @Negative @High @Automation
  Scenario: Verify a Delete-only user cannot create or edit via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Deleter_User1 |
    When the user sends a create request
    And the user sends an update request for Class-I
    Then Both requests are rejected (403); data unchanged

  # Ref: US-1 AC-4; FRD 5.1 BR-2
  @TC_CC_129 @Negative @High @Automation
  Scenario: Verify the 'Add' button is hidden on the list for a user without Add permission
    Given Viewer_User1 (Contractor Category: View only) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Viewer_User1 |
    When the user observes the list screen
    Then 'Add' button is not displayed anywhere on the list

  # Ref: FRD 5.1 BR-3; FRD Sec 7 (toasters only for listed events)
  @TC_CC_131 @Negative @Medium @Automation
  Scenario: Verify an unauthorized request displays no toaster message
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Viewer_User1 |
    When the user sends an unauthorized create request through the UI session with revoked Add permission
    And the user observes the screen
    Then Request is rejected and no toaster message is displayed
