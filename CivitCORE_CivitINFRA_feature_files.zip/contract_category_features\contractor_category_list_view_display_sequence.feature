@ContractorCategory @ContractorCategoryListViewDisplaySequence
Feature: Contractor Category List View - Display Sequence
  Automated scenarios for the "Contractor Category List View - Display Sequence" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: US-6 AC-1; FRD 5.3 SQ-1; FRD 5.3 SQ-2; FRD Sec 7 Toaster #5
  @TC_CC_049 @Functional @High @Automation
  Scenario: Verify dragging 'Class-IV' from position 4 to position 1 saves the order and shows the toaster
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row  | Class-IV |
      | From | 4        |
      | To   | 1        |
    When the user drags the handle of row 'Class-IV' (Sl. No. 4)
    And the user drops it at position 1
    Then Order is saved immediately (no Save button); 'Class-IV' is Sl. No. 1 and other rows move down by one
    And Toaster 'Sequence updated successfully.' is displayed

  # Ref: FRD 5.3 SQ-1; FRD 5.3 SQ-2
  @TC_CC_050 @Functional @High @Automation
  Scenario: Verify rows between the source and target positions move by one when a row is dragged downwards
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row  | Class-I |
      | From | 1       |
      | To   | 3       |
    When the user drags 'Class-I' (position 1)
    And the user drops it at position 3
    Then Order becomes Class-II, Class-III, Class-I, Class-IV; Sl. No. is re-sequenced

  # Ref: FRD 5.3 SQ-2; US-6 AC-1
  @TC_CC_051 @Functional @High @Automation
  Scenario: Verify the new sequence persists after page refresh
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-IV |
    When the user drags 'Class-IV' to position 1
    And the user refreshes the browser
    Then 'Class-IV' is still Sl. No. 1 after refresh

  # Ref: FRD 5.3 SQ-1; FRD 5.3 SQ-4
  @TC_CC_052 @Functional @Medium @Automation
  Scenario: Verify a row can be reordered within page 2
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | From | 55 |
      | To   | 51 |
    When the user goes to page 2
    And the user drags row Sl. No. 55 and drop it at Sl. No. 51
    Then Order is saved within page 2; toaster 'Sequence updated successfully.' is displayed; Sl. No. remains continuous (51 onwards)

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: FRD 5.1 BR-3; FRD 5.3 SQ-5
  @TC_CC_128 @Negative @High @Automation
  Scenario: Verify a user without Edit permission cannot change the sequence via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Viewer_User1 |
      | Row  | Class-IV     |
    When the user sends a sequence-change request moving Class-IV to position 1
    And the user checks the order
    Then Request is rejected (403); order unchanged; no toaster

  # Ref: US-6 AC-5; FRD 5.3 SQ-5
  @TC_CC_163 @Negative @High @Automation
  Scenario: Verify drag handles are disabled while a column search is active
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code search | Class |
    When the user types 'Class' in Code search
    And the user tries to drag a row
    Then Drag handles are disabled; rows cannot be moved and no toaster appears

  # Ref: US-6 AC-5; FRD 5.3 SQ-5
  @TC_CC_164 @Negative @High @Automation
  Scenario: Verify drag handles are disabled for a user without Edit permission
    Given Viewer_User1 (Contractor Category: View only) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Viewer_User1 |
    When the user tries to drag row 'Class-IV'
    Then Drag handles are disabled; rows cannot be moved

  # Ref: US-6 AC-2; FRD 5.3 SQ-4
  @TC_CC_165 @Negative @High @Automation
  Scenario: Verify a row on page 1 cannot be moved to another page
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Total records | 124 |
    When the user drags a row on page 1
    And the user attempts to drop it on page 2
    Then The row can be dropped only at a position within page 1; it cannot be moved to page 2

  # Ref: FRD 5.3 SQ-4
  @TC_CC_166 @Negative @Medium @Automation
  Scenario: Verify dropping a row outside the grid leaves the order unchanged
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-IV |
    When the user drags row 'Class-IV'
    And the user drops it outside the grid area
    Then Order remains unchanged; no sequence toaster and no Activity Log entry

  # Ref: US-6 AC-6; FRD 5.3 SQ-3; FRD Sec 7 Toaster #6
  @TC_CC_167 @Negative @High @Automation
  Scenario: Verify rows return to the previous order and the error toaster is shown when the sequence cannot be saved
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And The sequence-save service is forced to fail
    And the following test data is used
      | Row | Class-IV |
    When the user drags 'Class-IV' to position 1
    Then Rows return to their previous order and toaster 'Unable to update the sequence. Please try again.' is displayed
