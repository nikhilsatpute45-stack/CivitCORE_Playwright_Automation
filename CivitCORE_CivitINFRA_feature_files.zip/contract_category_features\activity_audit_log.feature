@ContractorCategory @ActivityAuditLog
Feature: Activity / Audit Log
  Automated scenarios for the "Activity / Audit Log" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: US-10 AC-1; FRD 6 FB-1; FRD 6 FB-3; FRD 6.1 A-Created
  @TC_CC_089 @Functional @High @Automation
  Scenario: Verify an Activity Log entry is written on creation with user, date-time, Code, Description and Specialization
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code           | Class-V       |
      | Description    | Class-V Roads |
      | Specialization | Civil         |
      | User           | Admin_User1   |
    When the user adds Contractor Category
    And the user opens the Activity Log section
    Then Entry 'Contractor Category Created' exists with User Admin_User1, Date-Time, Code 'Class-V', Description 'Class-V Roads' and Specialization 'Civil'

  # Ref: US-10 AC-2; FRD 6.1 A-Updated
  @TC_CC_090 @Functional @High @Automation
  Scenario: Verify an Activity Log entry on update lists each changed field with previous and new value
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Description    | Class-V Roads -> Class-V Highways |
      | Specialization | Civil -> Electrical               |
    When the user edits 'Class-V': change Description and Specialization
    And the user opens the Activity Log
    Then Entry 'Contractor Category Updated' shows User, Date-Time, Code and, for each changed field (Description, Specialization), Field Name, Previous Value and New Value

  # Ref: US-10 AC-1; FRD 6.1 A-Deleted
  @TC_CC_091 @Functional @High @Automation
  Scenario: Verify an Activity Log entry on deletion captures user, date-time, Code, Description and Specialization
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code           | Class-V       |
      | Description    | Class-V Roads |
      | Specialization | Civil         |
    When the user deletes unused 'Class-V' (Yes)
    And the user opens the Activity Log
    Then Entry 'Contractor Category Deleted' shows User, Date-Time, Code, Description and Specialization of the deleted record

  # Ref: US-10 AC-1; FRD 6.1 A-Blocked; FRD 6 FB-3
  @TC_CC_092 @Functional @High @Automation
  Scenario: Verify the Deletion Blocked entry captures user, date-time, Code and Reason
    Given Admin_User1 is logged in. 'Class-II' is used by CON-0001. on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code | Class-II |
    When the user selects Delete on 'Class-II'
    And the user opens the Activity Log
    Then Entry 'Contractor Category Deletion Blocked' shows User, Date-Time, Code 'Class-II' and Reason (used in Contractor Registration)

  # Ref: FRD 6.1 A-Sequence; FRD 6 FB-1
  @TC_CC_093 @Functional @High @Automation
  Scenario: Verify a Sequence Changed entry captures user, date-time, Code, previous position and new position
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code              | Class-IV |
      | Previous position | 4        |
      | New position      | 1        |
    When the user drags 'Class-IV' from position 4 to 1
    And the user opens the Activity Log
    Then Entry 'Sequence Changed' shows User, Date-Time, Code 'Class-IV', previous position 4 and new position 1

  # Ref: FRD 6 FB-2; FRD 5.2 BR-8
  @TC_CC_094 @Functional @High @Automation
  Scenario: Verify Activity Log entries are linked to the Contractor Category's Internal ID and stay linked after a rename
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code | Class-V -> Class-V-Rev1 |
    When the user creates 'Class-V'
    And the user renames Code to 'Class-V-Rev1' and Save
    And the user queries the Activity Log entries by Internal ID
    Then Both the Created and Updated entries are linked to the same Internal ID

  # Ref: FRD 6 FB-4
  @TC_CC_095 @Functional @Medium @Automation
  Scenario: Verify Activity Log entries are displayed most recent first
    Given Auditor_User1 (Activity Log view access) is logged in
    And Several Contractor Category actions were performed
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Auditor_User1 |
    When the user opens the Activity Log section
    And the user observes the order of entries
    Then Entries are listed most recent first

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: FRD 6 FB-4
  @TC_CC_188 @Negative @High @Automation
  Scenario: Verify Activity Log entries cannot be edited or deleted by any user
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Admin_User1 |
    When the user sends an edit request for an Activity Log entry
    And the user sends a delete request for an Activity Log entry
    Then Both requests are rejected; entries remain unchanged

  # Ref: FRD 5.4 BR-1; US-8 AC-3
  @TC_CC_189 @Negative @Medium @Automation
  Scenario: Verify no Activity Log entry is created when a delete confirmation is declined or a View is opened
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-V |
    When the user selects Delete on 'Class-V' and click No
    And the user opens 'Class-V' in View and close it
    And the user checks the Activity Log
    Then No new Activity Log entry is created for either action
