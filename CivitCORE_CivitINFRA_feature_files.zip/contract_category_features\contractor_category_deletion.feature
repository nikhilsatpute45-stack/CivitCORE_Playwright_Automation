@ContractorCategory @ContractorCategoryDeletion
Feature: Contractor Category Deletion
  Automated scenarios for the "Contractor Category Deletion" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: US-8 AC-1; FRD 5.8 FB-1; FRD 5.8 FB-2; FRD 5.8 FB-4; FRD 5.8 BR-2
  @TC_CC_084 @Functional @High @Automation
  Scenario: Verify confirmation dialog is shown for a Contractor Category that is not in use
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-V |
    When the user opens kebab of row 'Class-V' (not used in Contractor Registration)
    And the user selects Delete
    Then Confirmation dialog 'Are you sure you want to delete the Contractor Category “Class-V”?' is displayed with 'Yes' and 'No' buttons

  # Ref: US-8 AC-2; FRD 5.8 FB-5; FRD 5.8 DR-2; FRD Sec 7 Toaster #3
  @TC_CC_085 @Functional @High @Automation
  Scenario: Verify clicking Yes deletes the Contractor Category, shows the toaster and refreshes the list
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-V (Sl. No. 1) |
    When the user selects Delete on unused row 'Class-V'
    And the user clicks 'Yes'
    Then Contractor Category is deleted; toaster 'Contractor Category deleted successfully.' is displayed
    And List refreshes with Sl. No. re-sequenced and 'Class-V' no longer listed

  # Ref: US-8 AC-5; FRD 5.8 BR-4
  @TC_CC_086 @Functional @High @Automation
  Scenario: Verify the Code and Description of a deleted Contractor Category can be reused
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-V                   |
      | Description | Class-V Roads and Bridges |
    When the user deletes unused 'Class-V'
    And the user adds a new Contractor Category with the same Code and Description
    Then New Contractor Category is saved successfully; no duplicate error is shown

  # Ref: US-8 AC-4; FRD 5.8 FB-5
  @TC_CC_087 @Functional @High @Automation
  Scenario: Verify the empty state is shown after the last remaining Contractor Category is deleted
    Given Admin_User1 is logged in
    And Exactly one unused Contractor Category 'Class-V' exists. on the Contractor Category List (Admin > Configuration > Contractor Category)
    And the following test data is used
      | Row | Class-V |
    When the user selects Delete on 'Class-V'
    And the user clicks 'Yes'
    Then Toaster 'Contractor Category deleted successfully.' is displayed and the empty state is shown

  # Ref: FRD 5.8 FB-5
  @TC_CC_088 @Functional @Medium @Automation
  Scenario: Verify the previous page is shown when the last record on the last page is deleted
    Given Admin_User1 is logged in
    And Exactly 51 Contractor Categories exist (all unused); user is on page 2 showing 1 record
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Total records | 51 -> 50 |
    When the user selects Delete on the only row on page 2
    And the user clicks 'Yes'
    Then Record is deleted and the previous page (page 1) is shown

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: US-7 AC-1; FRD 5.8 FB-3; FRD 5.8 DR-1; FRD 5.7 BR-3; FRD Sec 7 Toaster #4
  @TC_CC_178 @Negative @High @Automation
  Scenario: Verify deletion is blocked with an error toaster and no confirmation dialog for a category used by a Registered contractor
    Given Admin_User1 is logged in. 'Class-II' is used by contractor CON-0001 (status Registered). on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-II |
    When the user opens kebab of 'Class-II'
    And the user selects Delete
    Then Error toaster 'This Contractor Category is used in Contractor Registration and cannot be deleted.' is displayed
    And Confirmation dialog is not shown; 'Class-II' remains

  # Ref: US-7 AC-1; FRD 5.7 BR-2; FRD 5.8 BR-1
  @TC_CC_179 @Negative @High @Automation
  Scenario: Verify deletion is blocked for a category used by a Black-listed contractor
    Given Admin_User1 is logged in. 'Class-III' is used by contractor CON-0002 (status Black-listed). on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-III |
    When the user selects Delete on 'Class-III'
    Then Deletion is blocked with the in-use error toaster; no confirmation dialog

  # Ref: US-7 AC-1; FRD 5.7 BR-2; FRD 5.8 BR-1
  @TC_CC_180 @Negative @High @Automation
  Scenario: Verify deletion is blocked for a category used by a Deleted contractor that remains visible in Contractor Registration
    Given Admin_User1 is logged in
    And Contractor Category 'Class-VI' is used by contractor CON-0003 (status Deleted, still visible in Contractor Registration). on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-VI |
    When the user selects Delete on 'Class-VI'
    Then Deletion is blocked with the in-use error toaster; no confirmation dialog

  # Ref: US-8 AC-3; FRD 5.8 FB-6; FRD 5.8 DR-3
  @TC_CC_181 @Negative @High @Automation
  Scenario: Verify clicking 'No' on the confirmation dialog leaves the category unchanged with no audit entry
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-V |
    When the user selects Delete on unused 'Class-V'
    And the user clicks 'No'
    And the user checks the list and Activity Log
    Then Dialog closes; 'Class-V' remains; no deletion entry in the Activity Log

  # Ref: US-8 AC-3; FRD 5.8 FB-6
  @TC_CC_182 @Negative @Medium @Automation
  Scenario: Verify closing the confirmation dialog with the X icon leaves the category unchanged
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-V |
    When the user selects Delete on unused 'Class-V'
    And the user clicks the close (X) icon of the dialog
    Then Dialog closes; 'Class-V' remains; no deletion entry in the Activity Log

  # Ref: FRD 5.8 FB-6
  @TC_CC_183 @Negative @Medium @Automation
  Scenario: Verify pressing Esc on the confirmation dialog leaves the category unchanged
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-V |
    When the user selects Delete on unused 'Class-V'
    And the user presses Esc
    Then Dialog closes; 'Class-V' remains unchanged

  # Ref: US-7 AC-2; FRD 5.8 FB-5; FRD 5.8 DR-4
  @TC_CC_184 @Negative @High @Automation
  Scenario: Verify the server re-checks the dependency on Yes and blocks deletion when a dependency was created after Delete was selected
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded. 'Class-V' is unused when Delete is selected
    And the following test data is used
      | Row            | Class-V  |
      | New contractor | CON-0004 |
    When the user selects Delete on 'Class-V' and keep the dialog open
    And In another session register a contractor under 'Class-V'
    And the user clicks 'Yes'
    Then Server check blocks the deletion; error toaster 'This Contractor Category is used in Contractor Registration and cannot be deleted.' is shown; 'Class-V' remains

  # Ref: FRD 5.8 FB-7
  @TC_CC_185 @Negative @Medium @Automation
  Scenario: Verify the list is refreshed with no toaster when the category was already deleted by another user
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And Another user deleted 'Class-V' after this list was loaded
    And the following test data is used
      | Row | Class-V (already deleted) |
    When the user selects Delete on row 'Class-V'
    Then List is refreshed; no toaster message is displayed

  # Ref: FRD 5.1 BR-3; FRD 5.1 BR-2
  @TC_CC_186 @Negative @High @Automation
  Scenario: Verify a user without Delete permission cannot delete via API for an unused category
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Editor_User1 |
      | Row  | Class-IV     |
    When the user sends a delete request for unused 'Class-IV'
    Then Request is rejected (403); 'Class-IV' remains; no toaster

  # Ref: US-7 AC-2; FRD 5.8 FB-5; FRD 5.8 BR-1
  @TC_CC_187 @Negative @High @Automation
  Scenario: Verify the server rejects deletion of a used category sent directly via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Admin_User1 |
      | Row  | Class-II    |
    When the user sends a delete request for used 'Class-II'
    Then Request is rejected as in use; 'Class-II' remains
