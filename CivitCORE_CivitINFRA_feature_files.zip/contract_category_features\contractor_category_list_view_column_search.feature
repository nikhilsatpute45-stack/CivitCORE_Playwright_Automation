@ContractorCategory @ContractorCategoryListViewColumnSearch
Feature: Contractor Category List View / Column Search
  Automated scenarios for the "Contractor Category List View / Column Search" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: FRD 5.3 FB-2; FRD 5.3 BR-2
  @TC_CC_029 @Functional @High @Automation
  Scenario: Verify 50 records per page with a 'current page / total pages' indicator and Sl. No. continuing on page 2
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Total records | 124 (4 baseline + 120 bulk) |
    When the user observes page 1
    And the user clicks Next
    And the user observes the first row of page 2
    Then Page 1 shows 50 records; indicator shows '1 / 3'
    And Page 2 starts with Sl. No. 51

  # Ref: FRD 5.3 FB-2
  @TC_CC_030 @Functional @Medium @Automation
  Scenario: Verify First and Previous are disabled on page 1
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Total records | 124 |
    When the user observes pagination controls on page 1
    Then First and Previous are disabled; Next, Last and page numbers are enabled

  # Ref: FRD 5.3 FB-2
  @TC_CC_031 @Functional @Medium @Automation
  Scenario: Verify Next and Last are disabled on the last page
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Total records | 124 |
    When the user clicks Last
    And the user observes pagination controls
    Then Indicator shows '3 / 3'; Next and Last are disabled; First and Previous are enabled

  # Ref: FRD 5.3 FB-2
  @TC_CC_032 @Functional @High @Automation
  Scenario: Verify First, Previous, Next, Last and page-number controls navigate correctly
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Total records | 124 |
    When the user clicks Next
    And the user clicks Last
    And the user clicks Previous
    And the user clicks First
    And the user clicks page number 2
    Then Each control opens the expected page (2, 3, 2, 1, 2) and the indicator updates accordingly

  # Ref: FRD 5.3 FB-2
  @TC_CC_033 @Functional @Medium @Automation
  Scenario: Verify pagination controls are hidden when there are exactly 50 records
    Given Admin_User1 is logged in and on the Contractor Category List with exactly 50 Contractor Categories in the master
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Total records | 50 |
    When the user observes the area below the grid
    Then All 50 records are shown on one page and pagination controls are hidden

  # Ref: FRD 5.3 FB-2
  @TC_CC_034 @Functional @Medium @Automation
  Scenario: Verify pagination controls appear when there are 51 records
    Given Admin_User1 is logged in and on the Contractor Category List with exactly 51 Contractor Categories in the master
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Total records | 51 |
    When the user observes the area below the grid
    Then Pagination controls are displayed with indicator '1 / 2'; page 2 holds 1 record

  # Ref: US-5 AC-1; FRD 5.3 FB-4
  @TC_CC_035 @Functional @High @Automation
  Scenario: Verify Code column search matches partial text ignoring letter case
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code search | class |
    When the user types in the Code column search box
    Then All four rows (Class-I to Class-IV) are shown

  # Ref: US-5 AC-1; FRD 5.3 FB-4
  @TC_CC_036 @Functional @High @Automation
  Scenario: Verify the list is filtered as the user types without pressing Enter
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code search | c -> class-IV |
    When the user types 'c' in the Code search box
    And the user continues typing 'lass-IV' without pressing Enter
    Then List filters after each keystroke; final result shows only 'Class-IV'

  # Ref: US-5 AC-1; FRD 5.3 FB-4
  @TC_CC_037 @Functional @High @Automation
  Scenario: Verify Description column search matches partial text ignoring letter case
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Description search | BRIDGES |
    When the user adds Contractor Category with Description 'Roads and Bridges'
    And the user types in the Description search box
    Then Only the row whose Description contains 'bridges' (any case) is shown

  # Ref: US-5 AC-2; FRD 5.3 FB-3
  @TC_CC_038 @Functional @High @Automation
  Scenario: Verify Specialization column search shows only Contractor Categories with the selected Specialization
    Given Admin_User1 is logged in
    And Records exist: Civ-A (Civil), Mech-A (Mechanical), Class-I (no Specialization)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Specialization search | Civil |
    When the user selects 'Civil' in the Specialization column search
    Then Only 'Civ-A' is shown

  # Ref: US-5 AC-2; FRD 5.3 FB-3
  @TC_CC_039 @Functional @High @Automation
  Scenario: Verify Specialization column search 'Blank' shows only Contractor Categories with no Specialization
    Given Admin_User1 is logged in
    And Records exist: Civ-A (Civil), Mech-A (Mechanical), Class-I (no Specialization)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Specialization search | Blank |
    When the user selects 'Blank' in the Specialization column search
    Then Only Contractor Categories with no Specialization (shown as '-') are listed; 'Civ-A' and 'Mech-A' are not shown

  # Ref: US-5 AC-2; FRD 5.3 FB-3; FRD 5.3 FB-5
  @TC_CC_040 @Functional @Medium @Automation
  Scenario: Verify Specialization column search defaults to 'All' and 'All' shows every Contractor Category
    Given Admin_User1 is logged in
    And Records exist: Civ-A (Civil), Mech-A (Mechanical), Class-I (no Specialization)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Specialization search | All |
    When the user observes the default value of the Specialization column search
    And the user selects 'Civil', then select 'All'
    Then Default value is 'All'
    And After selecting 'All' the full list is shown

  # Ref: US-5 AC-3; FRD 5.3 FB-4
  @TC_CC_041 @Functional @High @Automation
  Scenario: Verify searches in more than one column return only records matching all values
    Given Admin_User1 is logged in
    And Records exist: Civ-A (Civil, 'Civil A'), Civ-B (Civil, 'Civil B'), Mech-A (Mechanical, 'Mech A')
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Specialization | Civil |
      | Code           | Civ-B |
    When the user selects 'Civil' in Specialization search
    And the user types 'Civ-B' in Code search
    Then Only 'Civ-B' is shown (record matching both filters)

  # Ref: FRD 5.3 FB-5
  @TC_CC_042 @Functional @High @Automation
  Scenario: Verify clearing a column search removes that filter and the full list is shown on page 1
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Code search | bulk-0 then cleared |
    When the user types 'bulk-0' in Code search
    And the user goes to page 2
    And the user clears the Code search box
    Then Filter is removed; full list (124 records) is shown on page 1

  # Ref: FRD 5.3 FB-6; FRD 5.3 BR-2
  @TC_CC_043 @Functional @High @Automation
  Scenario: Verify filtered results are paginated from page 1 with Sl. No. starting from 1
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Code search | bulk-0 (matches Bulk-001 to Bulk-099 = 99 records) |
    When the user types 'bulk-0' in Code search
    And the user observes page 1
    And the user clicks Next
    Then Page 1 starts at Sl. No. 1 with 50 records; indicator '1 / 2'
    And Page 2 starts at Sl. No. 51 and shows 49 records

  # Ref: FRD 5.3 FB-4; US-5 AC-1
  @TC_CC_044 @Functional @Medium @Automation
  Scenario: Verify search with regex/special characters is matched literally as partial text
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code search | (Civil) & |
    When the user adds Contractor Category 'Class-I (Civil) & <Roads>'
    And the user types '(Civil) &' in Code search
    Then Only the row containing the literal text '(Civil) &' is shown; no error occurs

  # Ref: FRD 5.3 BR-2; US-8 AC-2
  @TC_CC_045 @Functional @Medium @Automation
  Scenario: Verify Sl. No. is re-sequenced continuously after every refresh
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Delete | Class-IV |
    When the user deletes an unused Contractor Category
    And the user observes Sl. No. of all remaining rows
    Then Sl. No. runs continuously 1, 2, 3 without gaps after the list refresh

  # Ref: FRD 5.3 FB-1
  @TC_CC_046 @Functional @Medium @Automation
  Scenario: Verify editing a Contractor Category does not change its position in the list
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code            | Class-II         |
      | New Description | Class-II Updated |
    When the user notes position of 'Class-II' (Sl. No. 2)
    And the user edits its Description and Save
    And the user observes the list
    Then 'Class-II' remains at Sl. No. 2

  # Ref: FRD 5.3 FB-7
  @TC_CC_047 @Functional @High @Automation
  Scenario: Verify list keeps column search values and page after an Edit
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Code search     | bulk-0                   |
      | Row             | Bulk-060                 |
      | New Description | Bulk Category 060 Edited |
    When the user types 'bulk-0' in Code search
    And the user goes to page 2
    And the user edits a row on page 2 and Save
    Then Pop-up closes; list refreshes keeping Code search 'bulk-0' and page 2

  # Ref: FRD 5.3 FB-7
  @TC_CC_048 @Functional @High @Automation
  Scenario: Verify list keeps column search values and page after a Delete
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Code search | bulk-0   |
      | Row         | Bulk-060 |
    When the user types 'bulk-0' in Code search
    And the user goes to page 2
    And the user deletes an unused row on page 2 and confirm Yes
    Then List refreshes keeping Code search 'bulk-0' and page 2

  # ---------------------------------------------------------------
  # UI / Visual scenarios
  # ---------------------------------------------------------------

  # Ref: US-1 AC-4; FRD 5.3 ES-Add
  @TC_CC_102 @UIVisual @High @Automation
  Scenario: Verify the empty state hides the 'Add' button for a user without Add permission but still shows illustration, heading and message
    Given Viewer_User1 (Contractor Category: View only) is logged in
    And No Contractor Category exists
    And the following test data is used
      | User | Viewer_User1 |
    When the user opens Contractor Category screen
    And the user observes the empty state
    Then Illustration, heading and message are shown; 'Add' button is not displayed

  # Ref: FRD 5.3 BR-4; US-2 AC-7
  @TC_CC_104 @UIVisual @Low @Automation
  Scenario: Verify '-' is displayed in the Specialization column when none is set
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-I |
    When the user observes row 'Class-I' (no Specialization)
    Then Specialization column shows '-'

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: US-5 AC-4; FRD 5.3 FB-8; FRD 5.3 ES-When
  @TC_CC_161 @Negative @High @Automation
  Scenario: Verify 'No records found.' is shown when the search has no match and the empty-state illustration is not shown
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code search | ZZZ-Unknown |
    When the user types a text not present in the Code search box
    Then Grid shows 'No records found.'; the empty-state illustration is not displayed

  # Ref: US-5 AC-3; FRD 5.3 FB-8
  @TC_CC_162 @Negative @Medium @Automation
  Scenario: Verify Specialization 'Blank' filter combined with a non-matching Code search shows 'No records found.'
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Specialization | Civil   |
      | Code           | Class-I |
    When the user selects 'Civil' in Specialization search
    And the user types 'Class-I' in Code search (Class-I has no Specialization)
    Then Grid shows 'No records found.' (all filters must match)
