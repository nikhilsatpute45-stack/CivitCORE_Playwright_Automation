@ContractorCategory @SpecializationDropdownValues
Feature: Specialization Dropdown Values
  Automated scenarios for the "Specialization Dropdown Values" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: US-2 AC-8; FRD 5.6 BR-1; FRD 5.6 BR-2
  @TC_CC_072 @Functional @High @Automation
  Scenario: Verify the Add pop-up Specialization dropdown lists exactly the Specialization Master values in display sequence
    Given Admin_User1 is logged in on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Specialization Master (CIC-F-001) 'List of Specialization' = Civil, Mechanical, Electrical
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Master values | Civil, Mechanical, Electrical |
    When the user clicks 'Add'
    And the user opens the Specialization dropdown
    Then Dropdown lists the placeholder 'Select Specialization' followed by Civil, Mechanical, Electrical in master display sequence, and no other values

  # Ref: FRD 5.3 FB-3; FRD 5.6 BR-2
  @TC_CC_073 @Functional @High @Automation
  Scenario: Verify the Specialization column search lists All, Blank and every Specialization Master value
    Given Admin_User1 is logged in on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Specialization Master 'List of Specialization' = Civil, Mechanical, Electrical
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Master values | Civil, Mechanical, Electrical |
    When the user opens the Specialization dropdown in the column search
    Then Dropdown lists All, Blank, Civil, Mechanical, Electrical; default selection is All

  # Ref: FRD 5.6 BR-3
  @TC_CC_074 @Functional @High @Automation
  Scenario: Verify a value added in the Specialization Master appears in the dropdown the next time Add/Edit pop-up is opened
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | New master value | Plumbing |
    When In the Specialization Master (CIC-F-001) add value 'Plumbing' under 'List of Specialization'
    And the user opens the Add Contractor Category pop-up
    And the user opens the Specialization dropdown
    Then 'Plumbing' is listed in the dropdown after the existing values, in master display sequence

  # Ref: FRD 5.6 BR-3
  @TC_CC_075 @Functional @Medium @Automation
  Scenario: Verify a Specialization renamed in the master is reflected in the list after refresh
    Given Admin_User1 is logged in
    And Contractor Category 'Civ-A' has Specialization 'Civil'. on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Master change | Civil -> Civil Works |
    When In the Specialization Master rename 'Civil' to 'Civil Works'
    And the user refreshes the Contractor Category List
    Then 'Civ-A' shows Specialization 'Civil Works' after the list is refreshed

  # Ref: FRD 5.6 BR-6
  @TC_CC_076 @Functional @Medium @Automation
  Scenario: Verify the dropdown keeps existing values when Display is unchecked for 'List of Specialization'
    Given Admin_User1 is logged in
    And In Miscellaneous Master (CIC-F-003) Display is unchecked for 'List of Specialization'. on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Misc Type | List of Specialization (Display unchecked) |
    When the user clicks 'Add'
    And the user opens the Specialization dropdown
    Then Dropdown still offers the existing values in their last saved display sequence

  # Ref: FRD 5.6 BR-5
  @TC_CC_077 @Functional @High @Automation
  Scenario: Verify a Specialization used by a Contractor Category cannot be deleted in the Specialization Master
    Given Admin_User1 is logged in
    And Contractor Category 'Civ-A' uses Specialization 'Civil'
    And User has access to Specialization Master (CIC-F-001)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Specialization | Civil |
    When the user opens the Specialization Master
    And the user attempts to delete the value 'Civil'
    Then Deletion of 'Civil' is not allowed because a Contractor Category refers to it (behavior defined by CIC-F-001)

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: FRD 5.2 BR-7; FRD 5.5 BR-4
  @TC_CC_177 @Negative @High @Automation
  Scenario: Verify the server rejects an update with a Specialization not in the Specialization Master
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User           | Admin_User1 |
      | Specialization | Welding     |
    When the user sends an update of Class-I with an unknown Specialization
    Then Request is rejected; Class-I is unchanged
