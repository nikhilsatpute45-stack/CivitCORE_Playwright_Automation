@ContractorCategory @ContractorCategoryCreation
Feature: Contractor Category Creation
  Automated scenarios for the "Contractor Category Creation" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: US-2 AC-1; FRD 5.2 FB-1; FRD 5.2 FB-5; FRD Sec 7 Toaster #1
  @TC_CC_011 @Functional @High @Automation
  Scenario: Verify a Contractor Category is created with Code, Description and Specialization
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code           | Class-V                   |
      | Description    | Class-V Roads and Bridges |
      | Specialization | Civil                     |
    When the user clicks 'Add'
    And the user enters Code
    And the user enters Description
    And the user selects Specialization
    And the user clicks Save
    Then Contractor Category is created and the pop-up closes
    And Success toaster 'Contractor Category added successfully.' is displayed
    And 'Class-V' is shown at the top of the list as Sl. No. 1 on page 1 with Specialization 'Civil'

  # Ref: US-2 AC-7; FRD 5.2 F-Spec; FRD 5.3 BR-4; FRD 5.6 BR-4
  @TC_CC_012 @Functional @High @Automation
  Scenario: Verify a Contractor Category is created without a Specialization and shows '-' in the list
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code           | Class-VI                              |
      | Description    | Class-VI General Works                |
      | Specialization | (placeholder 'Select Specialization') |
    When the user clicks 'Add'
    And the user enters Code
    And the user enters Description
    And the user leaves Specialization on 'Select Specialization'
    And the user clicks Save
    Then Contractor Category is saved with no Specialization
    And Specialization column shows '-' for 'Class-VI'

  # Ref: FRD 5.2 FB-5; FRD 5.3 ES-Add
  @TC_CC_013 @Functional @High @Automation
  Scenario: Verify the empty state is replaced by the list when the first Contractor Category is added
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in
    And No Contractor Category exists; the empty state is displayed
    And the following test data is used
      | Code        | Class-I |
      | Description | Class-I |
    When the user clicks 'Add' on the empty state
    And the user enters Code and Description
    And the user clicks Save
    Then Pop-up closes and toaster 'Contractor Category added successfully.' is displayed
    And Empty state is replaced by the list showing 'Class-I' as Sl. No. 1

  # Ref: FRD 5.2 FB-5; FRD 5.3 FB-7
  @TC_CC_014 @Functional @High @Automation
  Scenario: Verify after Add the list returns to page 1 and column search values are cleared
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Code search | bulk-1    |
      | New Code    | Class-VII |
      | Description | Class-VII |
    When the user enters 'bulk-1' in the Code column search
    And the user goes to page 2 of the result
    And the user clicks 'Add' and create a new Contractor Category
    And the user observes the list
    Then List shows page 1 with all column search values cleared
    And 'Class-VII' is visible at the top as Sl. No. 1

  # Ref: US-6 AC-4; FRD 5.3 FB-1
  @TC_CC_015 @Functional @High @Automation
  Scenario: Verify a newly added Contractor Category is placed at the top and existing ones move down by one
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Before | Class-I=1, Class-II=2, Class-III=3, Class-IV=4 |
      | New    | Class-V                                        |
    When the user notes the Sl. No. of Class-I to Class-IV
    And the user adds Contractor Category 'Class-V'
    And the user observes Sl. No. of all rows
    Then 'Class-V' is Sl. No. 1
    And Class-I=2, Class-II=3, Class-III=4, Class-IV=5

  # Ref: FRD 5.2 F-Code; FRD 5.2 BR-1
  @TC_CC_016 @Functional @Medium @Automation
  Scenario: Verify a Code of 1 character (minimum) is accepted
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | A                      |
      | Description | Single Letter Category |
    When the user enters Code
    And the user enters Description
    And the user clicks Save
    Then Contractor Category is saved; toaster 'Contractor Category added successfully.' is displayed

  # Ref: FRD 5.2 F-Code
  @TC_CC_017 @Functional @Medium @Automation
  Scenario: Verify a Code of exactly 50 characters (maximum) is accepted and saved in full
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | CODE-ABCDEFGHIJKLMNOPQRSTUVWXYZ-0123456789-ABCDEFGH (50 chars) |
      | Description | Max length code                                                |
    When the user enters a 50-character Code
    And the user enters Description
    And the user clicks Save
    And the user opens the saved record in View
    Then Contractor Category is saved with all 50 characters of Code
    And View pop-up shows the complete 50-character Code

  # Ref: FRD 5.2 F-Desc
  @TC_CC_018 @Functional @Medium @Automation
  Scenario: Verify a Description of exactly 200 characters (maximum) is accepted and saved in full
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-MaxDesc          |
      | Description | 'D' repeated 200 times |
    When the user enters Code
    And the user enters a 200-character Description
    And the user clicks Save
    And the user opens the saved record in View
    Then Contractor Category is saved with all 200 characters of Description
    And View pop-up shows the complete 200-character Description

  # Ref: FRD 5.2 BR-2; FRD 5.2 F-Code; FRD 5.2 F-Desc
  @TC_CC_019 @Functional @High @Automation
  Scenario: Verify leading and trailing spaces in Code and Description are removed before saving
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | ' Class-VIII '   |
      | Description | ' Eighth Class ' |
    When the user enters Code with leading and trailing spaces
    And the user enters Description with leading and trailing spaces
    And the user clicks Save
    And the user opens the saved record in View
    Then Saved Code is 'Class-VIII' and saved Description is 'Eighth Class' (no leading/trailing spaces)

  # Ref: FRD 5.2 BR-2
  @TC_CC_020 @Functional @High @Automation
  Scenario: Verify repeated internal spaces in Code and Description are reduced to one space
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | 'Class IX'          |
      | Description | 'Ninth Class Works' |
    When the user enters Code containing multiple internal spaces
    And the user enters Description containing multiple internal spaces
    And the user clicks Save
    And the user opens the saved record in View
    Then Saved Code is 'Class IX' and saved Description is 'Ninth Class Works'

  # Ref: FRD 5.2 BR-5
  @TC_CC_021 @Functional @Medium @Automation
  Scenario: Verify Code and Description are saved with the letter case exactly as entered
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | cLaSs-X     |
      | Description | tEnTh cLaSs |
    When the user enters Code in mixed case
    And the user enters Description in mixed case
    And the user clicks Save
    Then List shows Code 'cLaSs-X' and Description 'tEnTh cLaSs' with the same case as entered

  # Ref: US-2 AC-9; FRD 5.2 BR-6; FRD 5.2 BR-9
  @TC_CC_022 @Functional @High @Automation
  Scenario: Verify special characters in Code and Description are saved exactly as entered and shown as plain text
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-I (Civil) & <Roads>            |
      | Description | Roads & Bridges "Type-A" <Grade 'B'> |
    When the user enters Code containing special characters
    And the user enters Description containing special characters
    And the user clicks Save
    And the user observes the list row
    Then Contractor Category is saved without restriction
    And List shows the text exactly as entered, as plain text (no HTML rendering)

  # Ref: FRD 5.2 BR-9
  @TC_CC_023 @Functional @High @Automation
  Scenario: Verify script text in Code and Description is saved and displayed as plain text and never executed
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | <script>alert('XSS')</script> |
      | Description | <script>alert("XSS")</script> |
    When the user enters Code containing a script tag
    And the user enters Description containing a script tag
    And the user clicks Save
    And the user observes the list and open the record in View
    Then Record is saved exactly as entered
    And No alert or script execution occurs in the list, View pop-up or Contractor Registration; text appears as plain text (HTML-encoded)

  # Ref: FRD 5.2 BR-9
  @TC_CC_024 @Functional @High @Automation
  Scenario: Verify SQL injection text in Code and Description is stored as plain text (parameterized queries)
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | X'; DROP TABLE ContractorCategory;-- |
      | Description | ' OR '1'='1                          |
    When the user enters Code containing SQL text
    And the user enters Description containing SQL text
    And the user clicks Save
    And the user reloads the list
    Then Record is saved exactly as entered; the ContractorCategory table and all other records remain intact

  # Ref: FRD 5.2 BR-6; FRD 5.2 F-Code; FRD 5.2 F-Desc
  @TC_CC_025 @Functional @Medium @Automation
  Scenario: Verify Code and Description accept numbers and non-English/special symbols without restriction
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | 2026/Grade#10        |
      | Description | Zone-Ü ₹ @ ! % ^ * ~ |
    When the user enters Code with digits and symbols
    And the user enters Description with unicode symbols
    And the user clicks Save
    Then Record is saved exactly as entered; no character is rejected

  # Ref: FRD 5.2 BR-8
  @TC_CC_026 @Functional @High @Automation
  Scenario: Verify a system-generated unique Internal ID is created and not shown on any screen
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Records | Class-V and Class-VI |
    When the user creates two Contractor Categories
    And the user queries the Internal ID of both records at DB/API level
    And the user inspects list, View and Edit pop-ups for any ID
    Then Each record has a unique system-generated Internal ID
    And Internal ID is not displayed on the list, View pop-up or Edit pop-up and cannot be entered or edited

  # Ref: FRD 5.2 FB-5; FRD 5.4 FB-2
  @TC_CC_027 @Functional @Medium @Automation
  Scenario: Verify Created By and Created On are recorded when a Contractor Category is saved
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code | Class-V     |
      | User | Admin_User1 |
    When the user creates Contractor Category 'Class-V'
    And the user opens 'Class-V' in View
    Then Created By shows Admin_User1 and Created On shows the current date-time of creation

  # Ref: FRD 5.2 BR-3; FRD 5.2 BR-4; FRD 5.2 F-Spec
  @TC_CC_028 @Functional @Medium @Automation
  Scenario: Verify two Contractor Categories can share the same Specialization
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | 1) Code     | Civ-A                |
      | Description | Civil A              |
      | Spec        | Civil 2) Code: Civ-B |
      | Description | Civil B              |
      | Spec        | Civil                |
    When the user adds Contractor Category with Specialization 'Civil'
    And the user adds a second Contractor Category with different Code and Description and the same Specialization 'Civil'
    Then Both are saved; uniqueness is required only for Code and Description, not Specialization

  # ---------------------------------------------------------------
  # UI / Visual scenarios
  # ---------------------------------------------------------------

  # Ref: FRD 5.2 FB-2
  @TC_CC_108 @UIVisual @Low @Automation
  Scenario: Verify the cursor is placed in the Code field when the Add pop-up opens
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Field | Code |
    When the user clicks 'Add'
    And the user observes the focus
    Then Cursor is in the Code field

  # Ref: FRD 5.2 BR-7; FRD 5.2 F-Spec
  @TC_CC_109 @UIVisual @Medium @Automation
  Scenario: Verify Specialization is a single-select dropdown and does not accept free text
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Typed text | Plumbing |
    When the user clicks 'Add'
    And the user clicks into the Specialization field and try typing 'Plumbing'
    Then Only list selection is possible; typed text is not accepted as a value

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: US-2 AC-2; FRD 5.2 BR-1; FRD Sec 7 Field-Level Error #1
  @TC_CC_132 @Negative @High @Automation
  Scenario: Verify blank Code blocks Save with 'Code is required.'
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | (blank)       |
      | Description | Class-V Roads |
    When the user leaves Code blank
    And the user enters Description
    And the user clicks Save
    Then Save is blocked; message 'Code is required.' is shown below Code; no record is created and no toaster is displayed

  # Ref: US-2 AC-2; FRD 5.2 BR-2; FRD 5.2 F-Code
  @TC_CC_133 @Negative @High @Automation
  Scenario: Verify whitespace-only Code is treated as blank
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | ' ' (6 spaces) |
      | Description | Class-V Roads  |
    When the user enters only spaces in Code
    And the user enters Description
    And the user clicks Save
    Then Save is blocked; message 'Code is required.' is shown

  # Ref: US-2 AC-3; FRD 5.2 BR-1; FRD Sec 7 Field-Level Error #3
  @TC_CC_134 @Negative @High @Automation
  Scenario: Verify blank Description blocks Save with 'Description is required.'
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-V |
      | Description | (blank) |
    When the user enters Code
    And the user leaves Description blank
    And the user clicks Save
    Then Save is blocked; message 'Description is required.' is shown below Description; no record is created and no toaster is displayed

  # Ref: US-2 AC-3; FRD 5.2 BR-2; FRD 5.2 F-Desc
  @TC_CC_135 @Negative @High @Automation
  Scenario: Verify whitespace-only Description is treated as blank
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-V        |
      | Description | ' ' (6 spaces) |
    When the user enters Code
    And the user enters only spaces in Description
    And the user clicks Save
    Then Save is blocked; message 'Description is required.' is shown

  # Ref: US-2 AC-4; FRD 5.2 FB-4
  @TC_CC_136 @Negative @High @Automation
  Scenario: Verify both field-level errors are displayed at the same time when Code and Description are empty
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | (blank) |
      | Description | (blank) |
    When the user leaves both fields empty
    And the user clicks Save
    Then 'Code is required.' and 'Description is required.' are shown simultaneously; pop-up stays open; cursor moves to Code (first failing field)

  # Ref: FRD 5.2 FB-4
  @TC_CC_137 @Negative @Medium @Automation
  Scenario: Verify the cursor moves to Description and Code value is retained when only Description fails
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-V |
      | Description | (blank) |
    When the user enters Code
    And the user leaves Description blank
    And the user clicks Save
    Then Cursor is placed in Description; Code value 'Class-V' is retained; pop-up stays open

  # Ref: FRD 5.2 FB-6
  @TC_CC_138 @Negative @Medium @Automation
  Scenario: Verify a field-level error clears as soon as the value is corrected
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code | Class-V |
    When the user clicks Save with both fields empty
    And the user types a value in Code
    Then 'Code is required.' disappears as soon as Code is corrected; the Description error remains

  # Ref: FRD 5.2 F-Code
  @TC_CC_139 @Negative @Medium @Automation
  Scenario: Verify Code field does not accept more than 50 characters (typing stops)
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Input | 51 characters (A repeated 51 times) |
    When the user types 51 characters in Code
    And the user observes the box
    Then Box accepts only the first 50 characters

  # Ref: FRD 5.2 F-Code
  @TC_CC_140 @Negative @Medium @Automation
  Scenario: Verify pasted text longer than 50 characters in Code is cut at 50
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Paste | 'B' repeated 60 times |
    When the user pastes a 60-character text in Code
    Then Code box contains only the first 50 characters

  # Ref: FRD 5.2 F-Desc
  @TC_CC_141 @Negative @Medium @Automation
  Scenario: Verify Description field does not accept more than 200 characters (typing stops)
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Input | 201 characters |
    When the user types 201 characters in Description
    Then Box accepts only the first 200 characters

  # Ref: FRD 5.2 F-Desc
  @TC_CC_142 @Negative @Medium @Automation
  Scenario: Verify pasted text longer than 200 characters in Description is cut at 200
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Paste | 'C' repeated 250 times |
    When the user pastes a 250-character text in Description
    Then Description box contains only the first 200 characters

  # Ref: FRD 5.2 BR-3; FRD Sec 7 Field-Level Error #2
  @TC_CC_143 @Negative @High @Automation
  Scenario: Verify duplicate Code (exact match) is rejected
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-I               |
      | Description | Brand New Description |
    When the user enters an existing Code
    And the user enters a new Description
    And the user clicks Save
    Then Save is blocked; message 'A Contractor Category with this Code already exists.' is shown; no toaster; no record created

  # Ref: US-2 AC-5; FRD 5.2 BR-3
  @TC_CC_144 @Negative @High @Automation
  Scenario: Verify duplicate Code is rejected case-insensitively and after trimming spaces
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | ' class-i '           |
      | Description | Brand New Description |
    When the user enters ' class-i ' as Code
    And the user enters a new Description
    And the user clicks Save
    Then Save is blocked; message 'A Contractor Category with this Code already exists.' is shown

  # Ref: FRD 5.2 BR-2; FRD 5.2 BR-3
  @TC_CC_145 @Negative @High @Automation
  Scenario: Verify duplicate Code is rejected after repeated internal spaces are reduced
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | 1) Code     | Class A             |
      | 2) Code     | class a             |
      | Description | Another Description |
    When the user adds Contractor Category with Code 'Class A'
    And the user adds another with Code 'class a' and a new Description
    And the user clicks Save
    Then Second save is blocked with 'A Contractor Category with this Code already exists.'

  # Ref: FRD 5.2 BR-3; FRD 5.2 BR-4
  @TC_CC_146 @Negative @High @Automation
  Scenario: Verify duplicate Code is rejected regardless of a different Description and Specialization
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code           | CLASS-II |
      | Description    | New Desc |
      | Specialization | Civil    |
    When the user enters 'CLASS-II' as Code
    And the user enters a new Description
    And the user selects Specialization 'Civil'
    And the user clicks Save
    Then Save is blocked with 'A Contractor Category with this Code already exists.'

  # Ref: FRD 5.2 BR-4; FRD Sec 7 Field-Level Error #4
  @TC_CC_147 @Negative @High @Automation
  Scenario: Verify duplicate Description (exact match) is rejected
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-X1 |
      | Description | Class-I  |
    When the user enters a new Code
    And the user enters an existing Description
    And the user clicks Save
    Then Save is blocked; message 'A Contractor Category with this Description already exists.' is shown; no toaster; no record created

  # Ref: US-2 AC-6; FRD 5.2 BR-4
  @TC_CC_148 @Negative @High @Automation
  Scenario: Verify duplicate Description is rejected case-insensitively
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-X2 |
      | Description | CLASS-I  |
    When the user enters a new Code
    And the user enters 'CLASS-I' as Description
    And the user clicks Save
    Then Save is blocked with 'A Contractor Category with this Description already exists.'

  # Ref: FRD 5.2 BR-2; FRD 5.2 BR-4
  @TC_CC_149 @Negative @High @Automation
  Scenario: Verify duplicate Description is rejected after trimming and reducing internal spaces
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Description | ' roads AND bridges ' |
    When the user adds Contractor Category with Description 'Roads and Bridges'
    And the user adds another with a new Code and Description ' roads AND bridges '
    And the user clicks Save
    Then Second save is blocked with 'A Contractor Category with this Description already exists.'

  # Ref: FRD 5.2 FB-4; FRD 5.2 BR-4
  @TC_CC_150 @Negative @Medium @Automation
  Scenario: Verify duplicate Code and duplicate Description errors are shown together
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-I  |
      | Description | Class-II |
    When the user enters 'Class-I' as Code
    And the user enters 'Class-II' as Description
    And the user clicks Save
    Then Both 'A Contractor Category with this Code already exists.' and 'A Contractor Category with this Description already exists.' are shown at the same time; no record created

  # Ref: FRD 5.2 FB-3
  @TC_CC_151 @Negative @Medium @Automation
  Scenario: Verify the duplicate check is not run when a mandatory field fails on screen (fixed validation order)
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | (blank) |
      | Description | Class-I |
    When the user leaves Code blank
    And the user enters existing Description 'Class-I'
    And the user clicks Save
    Then Only 'Code is required.' is shown; the duplicate Description error is not shown because field-level checks run first on screen and duplicate checks run afterwards on the server

  # Ref: FRD 5.2 FB-4; FRD Sec 7 (toasters only for listed events)
  @TC_CC_152 @Negative @High @Automation
  Scenario: Verify validation failure keeps the pop-up open with all entered values retained and no toaster
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code           | Class-I           |
      | Description    | Fresh Description |
      | Specialization | Civil             |
    When the user enters Code 'Class-I' (existing)
    And the user enters Description 'Fresh Description'
    And the user selects Specialization 'Civil'
    And the user clicks Save
    Then Pop-up stays open; Code, Description and Specialization values are retained; Code field border is red; no toaster is displayed

  # Ref: FRD 5.2 FB-8; FRD 5.2 F-Save
  @TC_CC_153 @Negative @High @Automation
  Scenario: Verify Save is always enabled and a double click does not create two records
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-V       |
      | Description | Class-V Roads |
    When the user enters Code and Description
    And the user double-clicks Save quickly
    And the user checks the list
    Then Only one Contractor Category 'Class-V' is created; Save is disabled only while the save request is in progress

  # Ref: FRD 5.2 FB-7; FRD 5.2 F-Cancel
  @TC_CC_154 @Negative @High @Automation
  Scenario: Verify Cancel closes the Add pop-up without saving and without an audit entry
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-V       |
      | Description | Class-V Roads |
    When the user enters Code and Description
    And the user clicks Cancel
    And the user checks the list and Activity Log
    Then Pop-up closes; no record and no Activity Log entry is created

  # Ref: FRD 5.2 FB-7
  @TC_CC_155 @Negative @Medium @Automation
  Scenario: Verify the close (X) icon closes the Add pop-up without saving
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-V       |
      | Description | Class-V Roads |
    When the user enters Code and Description
    And the user clicks the close (X) icon
    And the user checks the list and Activity Log
    Then Pop-up closes; no record and no Activity Log entry is created

  # Ref: FRD 6 FB-1; FRD 5.2 FB-5
  @TC_CC_156 @Negative @Medium @Automation
  Scenario: Verify no audit entry is created when Save fails validation
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Add Contractor Category' pop-up is open
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-I |
      | Description | Fresh   |
    When the user enters Code 'Class-I' (existing) and Description 'Fresh'
    And the user clicks Save
    And the user checks the Activity Log
    Then No 'Contractor Category Created' entry is written

  # Ref: FRD 5.2 BR-9; FRD 5.2 BR-1
  @TC_CC_157 @Negative @High @Automation
  Scenario: Verify the server rejects a create request with blank Code or Description
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User     | Admin_User1                                                 |
      | Payloads | {code:'', description:'X'} and {code:'X1', description:' '} |
    When the user sends create requests with blank Code, then blank Description
    Then Both requests are rejected by the server; no record is created

  # Ref: FRD 5.2 BR-9; FRD 5.2 BR-3
  @TC_CC_158 @Negative @High @Automation
  Scenario: Verify the server rejects a duplicate Code sent directly via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User    | Admin_User1                                  |
      | Payload | {code:' CLASS-i ', description:'Direct API'} |
    When the user sends a create request with Code ' CLASS-i '
    Then Request is rejected as a duplicate Code; no record is created

  # Ref: FRD 5.2 BR-9; FRD 5.2 F-Code
  @TC_CC_159 @Negative @Medium @Automation
  Scenario: Verify the server does not store a Code longer than 50 characters
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Admin_User1   |
      | Code | 51 characters |
    When the user sends a create request with a 51-character Code
    Then No record with a Code longer than 50 characters is stored (over-length handling via API is not specified; see Assumptions)

  # Ref: FRD 5.2 BR-7; FRD 5.2 BR-9
  @TC_CC_160 @Negative @High @Automation
  Scenario: Verify the server rejects a Specialization value that is not in the Specialization Master
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User           | Admin_User1             |
      | Specialization | Welding (not in master) |
    When the user sends a create request with an unknown Specialization
    Then Request is rejected; no record is created with a Specialization outside the master
