@ContractorCategory @ContractorCategoryConsumptionContractorRegistration
Feature: Contractor Category Consumption - Contractor Registration
  Automated scenarios for the "Contractor Category Consumption - Contractor Registration" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: US-9 AC-1; FRD 5.7 FB-1
  @TC_CC_078 @Functional @High @Automation
  Scenario: Verify the Contractor Registration Category dropdown lists categories as 'Code - Description' in master order with placeholder 'Select'
    Given Admin_User1 is logged in and on the Contractor Registration screen
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Expected | Select, Class-I - Class-I, Class-II - Class-II, Class-III - Class-III, Class-IV - Class-IV |
    When the user opens the Category dropdown
    Then Dropdown lists placeholder 'Select' first, then each Contractor Category as 'Code - Description' in the display sequence of the master

  # Ref: US-9 AC-2; FRD 5.7 FB-2
  @TC_CC_079 @Functional @High @Automation
  Scenario: Verify a newly added Contractor Category is available in Contractor Registration without further configuration
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | Class-V       |
      | Description | Class-V Roads |
    When the user adds Contractor Category 'Class-V' / 'Class-V Roads'
    And the user opens (or refresh) Contractor Registration
    And the user opens the Category dropdown
    Then 'Class-V - Class-V Roads' is listed at the top of the options (Sl. No. 1 order)

  # Ref: US-9 AC-3; FRD 5.7 FB-3; FRD 5.5 BR-3
  @TC_CC_080 @Functional @High @Automation
  Scenario: Verify an edited Code/Description is shown in Contractor Registration including for already registered contractors
    Given Admin_User1 is logged in
    And Contractor CON-0001 is registered under 'Class-II'. on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code            | Class-II         |
      | New Description | Class-II Revised |
    When the user edits 'Class-II' Description to 'Class-II Revised' and Save
    And the user opens Contractor Registration and view CON-0001
    And the user opens the Category dropdown
    Then CON-0001 shows 'Class-II - Class-II Revised' as its Category and the dropdown shows the same text

  # Ref: US-6 AC-3; FRD 5.3 SQ-6; FRD 5.7 FB-1
  @TC_CC_081 @Functional @High @Automation
  Scenario: Verify the Category dropdown follows the display sequence changed by drag and drop
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-IV |
    When the user drags 'Class-IV' to position 1
    And the user opens Contractor Registration and the Category dropdown
    Then 'Class-IV - Class-IV' is listed first after the placeholder 'Select'; other options follow in master order

  # Ref: US-9 AC-4; FRD 5.7 FB-4; US-8 AC-2
  @TC_CC_082 @Functional @High @Automation
  Scenario: Verify a deleted Contractor Category is no longer offered in Contractor Registration
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code | Class-V |
    When the user deletes unused Contractor Category 'Class-V' (Yes)
    And the user opens Contractor Registration and the Category dropdown
    Then 'Class-V' is not listed in the Category dropdown

  # Ref: FRD 5.7 BR-1; FRD 5.5 BR-3
  @TC_CC_083 @Functional @High @Automation
  Scenario: Verify Contractor Registration references the category by Internal ID (rename does not break the link)
    Given Admin_User1 is logged in
    And Contractor CON-0001 is registered under 'Class-II'. on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code | Class-II -> Class-II-X |
    When the user queries the category reference stored on CON-0001 (DB/API)
    And the user renames Code of 'Class-II' to 'Class-II-X' and Save
    And the user queries the reference again
    Then The stored reference is the Internal ID in both queries (not Code/Description) and CON-0001 remains linked to the category
