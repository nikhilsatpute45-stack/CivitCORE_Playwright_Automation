@ContractorCategory @ContractorCategoryUpdate
Feature: Contractor Category Update
  Automated scenarios for the "Contractor Category Update" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: US-4 AC-1; FRD 5.5 FB-1; FRD 5.5 FB-2
  @TC_CC_060 @Functional @High @Automation
  Scenario: Verify the Edit pop-up opens pre-filled with current values and all three fields are editable
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-V (Description: Class-V Roads and Bridges, Specialization: Civil) |
    When the user opens kebab of row 'Class-V' and select Edit
    And the user observes the pop-up
    And the user modifies Code, Description and Specialization
    Then 'Edit Contractor Category' pop-up shows current Code, Description and Specialization
    And All three fields are editable

  # Ref: US-4 AC-2; FRD 5.5 FB-4; FRD Sec 7 Toaster #2
  @TC_CC_061 @Functional @High @Automation
  Scenario: Verify updating the Code saves, shows the success toaster and reflects in the list
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row      | Class-V      |
      | New Code | Class-V-Rev1 |
    When the user changes Code
    And the user clicks Save
    Then Contractor Category is updated and pop-up closes
    And Toaster 'Contractor Category updated successfully.' is displayed
    And List shows 'Class-V-Rev1'

  # Ref: US-4 AC-2; FRD 5.5 FB-4
  @TC_CC_062 @Functional @High @Automation
  Scenario: Verify updating the Description saves and reflects in the list
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row             | Class-V          |
      | New Description | Class-V Highways |
    When the user changes Description
    And the user clicks Save
    Then Toaster 'Contractor Category updated successfully.' is displayed and list shows 'Class-V Highways'

  # Ref: FRD 5.5 FB-2; FRD 5.6 BR-4; FRD 5.3 BR-4
  @TC_CC_063 @Functional @Medium @Automation
  Scenario: Verify Specialization can be changed from none to a value and back to none
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row            | Class-VI                       |
      | Specialization | (none) -> Electrical -> (none) |
    When the user selects 'Electrical' in Specialization and Save
    And the user edits again and select the placeholder 'Select Specialization' and Save
    Then After the first save the list shows 'Electrical'
    And After the second save the list shows '-' (no Specialization)

  # Ref: US-4 AC-3; FRD 5.5 BR-1
  @TC_CC_064 @Functional @High @Automation
  Scenario: Verify changing only the letter case of the record's own Code is allowed
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row  | Class-I            |
      | Code | Class-I -> class-i |
    When the user changes Code to a different letter case
    And the user clicks Save
    Then No duplicate error is shown; Code is saved as 'class-i'; toaster 'Contractor Category updated successfully.' is displayed

  # Ref: US-4 AC-3; FRD 5.5 BR-1
  @TC_CC_065 @Functional @High @Automation
  Scenario: Verify changing only the letter case of the record's own Description is allowed
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row         | Class-I            |
      | Description | Class-I -> CLASS-I |
    When the user changes Description to a different letter case
    And the user clicks Save
    Then No duplicate error is shown; Description is saved as 'CLASS-I'; toaster 'Contractor Category updated successfully.' is displayed

  # Ref: FRD 5.5 BR-1
  @TC_CC_066 @Functional @High @Automation
  Scenario: Verify changing only the Description keeps the unchanged own Code from raising a duplicate error
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row         | Class-I                    |
      | Description | Class-I -> Class-I Revised |
    When the user keeps Code unchanged
    And the user changes Description
    And the user clicks Save
    Then Update succeeds; uniqueness check excludes the record being edited

  # Ref: US-4 AC-4; FRD 5.5 BR-2
  @TC_CC_067 @Functional @High @Automation
  Scenario: Verify a Contractor Category used in Contractor Registration can be edited
    Given Admin_User1 is logged in. 'Class-II' is used by contractor CON-0001 (status Registered). on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row             | Class-II         |
      | New Description | Class-II Updated |
    When the user edits 'Class-II' and change Description
    And the user clicks Save
    Then Update is allowed; toaster 'Contractor Category updated successfully.' is displayed

  # Ref: FRD 5.2 BR-8; FRD 5.5 BR-3
  @TC_CC_068 @Functional @High @Automation
  Scenario: Verify the Internal ID does not change after renaming or changing Specialization
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-V |
    When the user notes the Internal ID of 'Class-V' (DB/API)
    And the user changes Code, Description and Specialization and Save
    And the user queries the Internal ID again
    Then Internal ID is identical before and after the update

  # Ref: FRD 5.5 BR-4; FRD 5.2 BR-2
  @TC_CC_069 @Functional @Medium @Automation
  Scenario: Verify Edit applies the same space handling as creation
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code        | ' Class V2 '            |
      | Description | ' Fifth Class Updated ' |
    When the user enters Code and Description with leading/trailing and repeated internal spaces
    And the user clicks Save
    Then Saved Code is 'Class V2' and saved Description is 'Fifth Class Updated'

  # Ref: FRD 5.5 BR-4; FRD 5.2 BR-9
  @TC_CC_070 @Functional @Medium @Automation
  Scenario: Verify special characters are accepted and shown as plain text on update
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row         | Class-V                         |
      | Description | <b>Bold</b> & 'quotes' "double" |
    When the user changes Description to text with special characters
    And the user clicks Save
    Then Update succeeds; list shows the text exactly as entered, as plain text

  # Ref: US-4 AC-5; FRD 5.5 FB-5
  @TC_CC_071 @Functional @High @Automation
  Scenario: Verify clicking Save with no change closes the pop-up without update, toaster or Activity Log entry
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-I |
    When the user does not change any field
    And the user clicks Save
    And the user checks the Activity Log and Last Modified On
    Then Pop-up closes; no toaster is displayed; record is not updated (Last Modified unchanged); no Activity Log entry is created

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: FRD 5.5 FB-3; FRD 5.5 BR-4; FRD Sec 7 Field-Level Error #1
  @TC_CC_169 @Negative @High @Automation
  Scenario: Verify Edit with blank Code is blocked with 'Code is required.'
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row  | Class-I |
      | Code | (blank) |
    When the user clears Code
    And the user clicks Save
    Then Save is blocked; 'Code is required.' is shown; no toaster; record unchanged

  # Ref: FRD 5.5 FB-3; FRD 5.5 BR-4; FRD Sec 7 Field-Level Error #3
  @TC_CC_170 @Negative @High @Automation
  Scenario: Verify Edit with blank Description is blocked with 'Description is required.'
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row         | Class-I |
      | Description | (blank) |
    When the user clears Description
    And the user clicks Save
    Then Save is blocked; 'Description is required.' is shown; no toaster; record unchanged

  # Ref: FRD 5.5 BR-4; FRD 5.2 BR-2
  @TC_CC_171 @Negative @Medium @Automation
  Scenario: Verify Edit with whitespace-only Code is blocked
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row  | Class-I |
      | Code | ' '     |
    When the user replaces Code with spaces
    And the user clicks Save
    Then Save is blocked with 'Code is required.'

  # Ref: US-4 AC-3; FRD 5.5 FB-3; FRD Sec 7 Field-Level Error #2
  @TC_CC_172 @Negative @High @Automation
  Scenario: Verify changing Code to the Code of another Contractor Category is rejected
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row  | Class-I  |
      | Code | class-ii |
    When the user changes Code to another record's Code
    And the user clicks Save
    Then Save is blocked; 'A Contractor Category with this Code already exists.' is shown; record unchanged

  # Ref: US-4 AC-3; FRD 5.5 FB-3; FRD Sec 7 Field-Level Error #4
  @TC_CC_173 @Negative @High @Automation
  Scenario: Verify changing Description to the Description of another Contractor Category is rejected
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row         | Class-I   |
      | Description | CLASS-III |
    When the user changes Description to another record's Description
    And the user clicks Save
    Then Save is blocked; 'A Contractor Category with this Description already exists.' is shown; record unchanged

  # Ref: US-4 AC-6; FRD 5.5 FB-6
  @TC_CC_174 @Negative @High @Automation
  Scenario: Verify Cancel on Edit closes the pop-up without saving
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row         | Class-I          |
      | Description | Edited Not Saved |
    When the user changes Description
    And the user clicks Cancel
    And the user observes the list
    Then Pop-up closes; Description remains unchanged; no toaster and no Activity Log entry

  # Ref: US-4 AC-6; FRD 5.5 FB-6
  @TC_CC_175 @Negative @Medium @Automation
  Scenario: Verify the close (X) icon on Edit closes the pop-up without saving
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and the 'Edit Contractor Category' pop-up is open for the Contractor Category named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row         | Class-I          |
      | Description | Edited Not Saved |
    When the user changes Description
    And the user clicks the close (X) icon
    Then Pop-up closes; no change is saved

  # Ref: FRD 5.5 BR-4; FRD 5.2 BR-9
  @TC_CC_176 @Negative @High @Automation
  Scenario: Verify the server rejects a duplicate Code on update sent directly via API
    Given API client authenticated with the token of the user named in Test Data
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User    | Admin_User1                   |
      | Payload | {id:Class-I, code:'CLASS-II'} |
    When the user sends an update of Class-I with Code 'CLASS-II'
    Then Request is rejected; Class-I is unchanged
