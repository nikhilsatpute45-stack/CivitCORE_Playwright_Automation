@ContractorCategory @ContractorCategoryView
Feature: Contractor Category View
  Automated scenarios for the "Contractor Category View" module of Contractor Category.
  Source: CivitINFRA_Contractor_Category_TestCases.xlsx (only rows with Execution Type = Automation).
  FRD Reference: CIC-F-002_CivitINFRA Configuration_Contractor_Category.pdf (Ver 1.0, 03-Nov-2026)

  # ---------------------------------------------------------------
  # Functional (positive) scenarios
  # ---------------------------------------------------------------

  # Ref: US-3 AC-1; FRD 5.4 FB-1; FRD 5.4 FB-2
  @TC_CC_053 @Functional @High @Automation
  Scenario: Verify View pop-up shows all details in read-only mode
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row            | Class-V |
      | Specialization | Civil   |
    When the user clicks kebab of row 'Class-V' (created by Admin_User1 with Specialization Civil)
    And the user selects View
    Then 'View Contractor Category' pop-up shows Code, Description, Specialization, Created By, Created On, Last Modified By and Last Modified On
    And All values are read-only

  # Ref: FRD 5.4 FB-2
  @TC_CC_054 @Functional @Medium @Automation
  Scenario: Verify View shows '-' for no Specialization and for Last Modified By/On when never modified
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code | Class-VI |
    When the user creates Contractor Category 'Class-VI' without Specialization
    And the user opens it in View
    Then Specialization shows '-'
    And Last Modified By and Last Modified On show '-'

  # Ref: FRD 5.5 FB-4; FRD 5.4 FB-2
  @TC_CC_055 @Functional @Medium @Automation
  Scenario: Verify Last Modified By and Last Modified On are shown after an update
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Code            | Class-V         |
      | New Description | Class-V Updated |
    When the user edits 'Class-V' Description as Admin_User1 and Save
    And the user opens 'Class-V' in View
    Then Last Modified By shows Admin_User1 and Last Modified On shows the update date-time

  # Ref: FRD 5.4 FB-3; FRD 5.5 FB-1; US-3 AC-2
  @TC_CC_056 @Functional @High @Automation
  Scenario: Verify the Edit button on the View pop-up opens the Edit pop-up for the same Contractor Category
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-V |
    When the user opens 'Class-V' in View
    And the user clicks 'Edit'
    Then 'Edit Contractor Category' pop-up opens pre-filled with the values of 'Class-V'

  # Ref: US-3 AC-2; FRD 5.4 FB-4
  @TC_CC_057 @Functional @Medium @Automation
  Scenario: Verify Close on View returns to the same page with the same column search values
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Code search | bulk-0 |
      | Page        | 2      |
    When the user types 'bulk-0' in Code search
    And the user goes to page 2
    And the user opens a row in View
    And the user clicks 'Close'
    Then View pop-up closes; list shows page 2 with Code search 'bulk-0' retained

  # Ref: FRD 5.4 FB-4
  @TC_CC_058 @Functional @Medium @Automation
  Scenario: Verify the close (X) icon on View returns to the same page with the same column search values
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data plus 120 bulk Contractor Categories (Bulk-001 to Bulk-120) are loaded (see Summary)
    And the following test data is used
      | Code search | bulk-0 |
      | Page        | 2      |
    When the user types 'bulk-0' in Code search
    And the user goes to page 2
    And the user opens a row in View
    And the user clicks the close (X) icon
    Then View pop-up closes; list shows page 2 with Code search 'bulk-0' retained

  # Ref: FRD 5.4 BR-1
  @TC_CC_059 @Functional @High @Automation
  Scenario: Verify View does not change data or create an Activity Log entry
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | Row | Class-I |
    When the user notes the Activity Log entry count for 'Class-I'
    And the user opens 'Class-I' in View and close it
    And the user checks the Activity Log
    Then No data is changed and no new Activity Log entry is created

  # ---------------------------------------------------------------
  # UI / Visual scenarios
  # ---------------------------------------------------------------

  # Ref: US-3 AC-2; FRD 5.1 BR-2; FRD 5.4 FB-2
  @TC_CC_111 @UIVisual @High @Automation
  Scenario: Verify the View pop-up is read-only and shows Edit only to users with Edit permission
    Given Viewer_User1 (Contractor Category: View only) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Viewer_User1 |
      | Row  | Class-I      |
    When the user opens 'Class-I' in View
    And the user tries to edit each field
    And the user observes the buttons
    Then Pop-up titled 'View Contractor Category' shows all fields read-only
    And 'Edit' button is not displayed; 'Close' button and close (X) icon are displayed

  # Ref: US-3 AC-2; FRD 5.4 FB-3
  @TC_CC_112 @UIVisual @Medium @Automation
  Scenario: Verify the View pop-up shows the Edit button for a user with Edit permission
    Given Editor_User1 (Contractor Category: View + Edit) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Editor_User1 |
    When the user opens 'Class-I' in View
    And the user observes the buttons
    Then 'Edit' button is displayed along with 'Close'

  # ---------------------------------------------------------------
  # Negative scenarios
  # ---------------------------------------------------------------

  # Ref: FRD 5.1 BR-2; US-3 AC-2
  @TC_CC_130 @Negative @High @Automation
  Scenario: Verify the Edit button is not shown on the View pop-up for a user without Edit permission
    Given Viewer_User1 (Contractor Category: View only) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And the following test data is used
      | User | Viewer_User1 |
    When the user opens 'Class-I' in View
    Then 'Edit' button is not displayed on the View pop-up

  # Ref: FRD 5.4 BR-2
  @TC_CC_168 @Negative @Medium @Automation
  Scenario: Verify the list is refreshed with no toaster when the category was deleted by another user before View is opened
    Given Admin_User1 (Contractor Category: View/Add/Edit/Delete) is logged in and on the Contractor Category List (Admin > Configuration > Contractor Category)
    And Baseline data (see Summary) is loaded
    And Another user has deleted 'Class-V' after this list was loaded
    And the following test data is used
      | Row | Class-V (already deleted) |
    When the user selects View on row 'Class-V'
    Then List is refreshed; 'Class-V' is no longer listed; no toaster message is displayed
